
function toggleMenu() {
    let nav = document.querySelector('.nav-links');

    if (nav.classList.contains("show")) {
        nav.classList.remove("show");
        setTimeout(() => {
            nav.style.display = "none"; // Hide after animation
        }, 300);
    } else {
        nav.style.display = "flex";
        setTimeout(() => {
            nav.classList.add("show");
        }, 10);
    }
}

// Hide menu when clicking outside
document.addEventListener("click", function (event) {
    let nav = document.querySelector(".nav-links");
    let menuToggle = document.querySelector(".menu-toggle");

    if (nav.classList.contains("show") && !nav.contains(event.target) && !menuToggle.contains(event.target)) {
        nav.classList.remove("show");
        setTimeout(() => {
            nav.style.display = "none";
        }, 300);
    }
});

// Hide menu when scrolling
window.addEventListener("scroll", function () {
    let nav = document.querySelector(".nav-links");
    if (nav.classList.contains("show")) {
        nav.classList.remove("show");
        setTimeout(() => {
            nav.style.display = "none";
        }, 300);
    }
});
